Hai mod trong thư mục này CHỈ dùng cho macOS:

  macos-input-fixes-1.16.jar   Fix scroll/ctrl-click/chuột trên macOS
                               (MC-22882, MC-59810, MC-121772, MC-122296)
  retiNO-ver-26.1-1.1.0.jar    Render nửa độ phân giải trên màn Retina
                               (set GLFW_COCOA_RETINA_FRAMEBUFFER = false)

Trên Windows/Linux: ĐỪNG copy vào mods/ — vô dụng.
  - macos-input-fixes: có MixinPlugin nhưng shouldApplyMixin() luôn trả true,
    chỉ Common.IS_SYSTEM_MAC gate phần logic. Nạp được, không làm gì.
  - retiNO: mixin gọi glfwWindowHint(0x23001, false). Trên Windows/Linux GLFW
    trả GLFW_INVALID_ENUM rồi bỏ qua hint — không crash, chỉ thêm 1 dòng lỗi
    trong log. Không ảnh hưởng hình ảnh.

Trên macOS: copy cả hai vào mods/.
